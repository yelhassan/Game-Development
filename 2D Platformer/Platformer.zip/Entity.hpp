//
//  Entity.hpp
//  NYUCodebase
//
//  Created by Yousra on 10/31/18.
//  Copyright © 2018 Ivan Safrin. All rights reserved.
//

#ifndef Entity_hpp
#define Entity_hpp

#include <stdio.h>

#endif /* Entity_hpp */
